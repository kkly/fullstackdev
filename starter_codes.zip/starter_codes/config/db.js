module.exports = {
	host: 'localhost',
	database: 'foodjournal',
	username: 'itp211',
	password: 'itp211'
}