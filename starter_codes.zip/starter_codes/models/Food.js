const Sequelize = require('sequelize');
const db = require('../config/DBConfig');

/* 	Creates a user(s) table in MySQL Database. 
	Note that Sequelize automatically pleuralizes the entity name as the table name
*/
const Food = db.define('food', { 	
	entry: {
		type: Sequelize.STRING
    },
    dateOfEntry:{
        type: Sequelize.DATE
    },
    cuisine: {
        type: Sequelize.STRING
    },
    diningPlace: {
        type: Sequelize.STRING
    },
    mealType: {
        type: Sequelize.STRING
    },
    calories: {
        type: Sequelize.INTEGER
    }, 
    mood: {
        type: Sequelize.STRING
    }
});

module.exports = Food;