const express = require('express');
const router = express.Router();



router.get('/', (req, res) => {
	const title = 'Food Journal';
	res.render('index', { title: title }) // renders views/index.handlebars
});

// Logout User
router.get('/logout', (req, res) => {
	req.logout();
	res.redirect('/');
});

router.get('/addFood', (req,res)=>{
	res.render("food/addFood");
});

router.get('/editFood', (req, res)=> {
	res.render('food/editFood');
});

router.get('/showRegister', (req, res)=>{
	res.render('user/register');
})

module.exports = router;
